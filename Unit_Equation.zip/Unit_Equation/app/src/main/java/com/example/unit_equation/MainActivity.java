package com.example.unit_equation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    private Button unit_s;
    private Button pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pref = (Button) findViewById(R.id.mathButton);
        unit_s = (Button) findViewById(R.id.conButton);
        pref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open_converter();
            }
        });
         unit_s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open_math();
            }
        });
    }
    public void open_converter() {
        Intent intent = new Intent(this, Converter.class);
        startActivity(intent);
    }
        public void open_math() {
        Intent intent = new Intent(this, Math.class);
        startActivity(intent);
    }

}
